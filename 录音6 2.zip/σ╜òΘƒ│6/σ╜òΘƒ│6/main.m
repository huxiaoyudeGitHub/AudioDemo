//
//  main.m
//  录音6
//
//  Created by 王蓉 on 2017/7/7.
//  Copyright © 2017年 王蓉. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
