//
//  ViewController.h
//  录音6
//
//  Created by 王蓉 on 2017/7/7.
//  Copyright © 2017年 王蓉. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
@interface ViewController : UIViewController<AVAudioRecorderDelegate>


@end

